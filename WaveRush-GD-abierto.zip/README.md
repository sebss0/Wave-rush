# WaveRush — ZIP con compilación corregida

## IMPORTANTE: cómo subirlo a GitHub
No subas este ZIP al repositorio como un único archivo. Descárgalo, descomprímelo y sube **todo lo que hay dentro** a la raíz del repositorio. Debes ver `package.json` directamente en la pestaña Code, junto a `www/`, `capacitor.config.json` y `.github/`.

El workflow incluido también intenta extraer ZIPs que encuentre en el repositorio y busca `package.json` dentro de carpetas, para evitar el error anterior.

## Compilar
1. Sube los archivos descomprimidos a la raíz del repositorio (reemplaza el workflow anterior).
2. Abre Actions.
3. Ejecuta `Compilar WaveRush APK`.
4. Descarga el artefacto `WaveRush-Android-APK`.

El workflow genera un APK debug. La compilación aún debe ejecutarse en GitHub y probarse en el teléfono.
